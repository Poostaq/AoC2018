﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Linq;

namespace AoC2018.Day3
{
    class DayThree
    {
        List<string> input;
        List<Dictionary<string, int>> Claims;
        List<List<int>> fabric;
        int fabricArea;

        public DayThree()
        {
            int fabricWidth = 0;
            int fabricHeigth = 0;
            int fabricArea = 0;
            fabric = new List<List<int>>();
            this.input = File.ReadAllLines("D://Repos//AoC2018//AoC2018//Day3//Day3.txt").ToList();
            foreach (string claim in input)
            {
                IList<string> splitClaim = claim.Split(" ");
                Dictionary<string, int> newClaim = new Dictionary<string, int>();
                newClaim.Add("ID", Int32.Parse(splitClaim[0].Substring(0)));
                IList<string> leftntop = splitClaim[2].Substring(0, splitClaim[2].Length - 1).Split(".");
                newClaim.Add("Left", Int32.Parse(leftntop[0]));
                newClaim.Add("Top", Int32.Parse(leftntop[1]));
                IList<string> widthnheight = splitClaim[3].Split("x");
                newClaim.Add("Width", Int32.Parse(widthnheight[0]));
                newClaim.Add("Height", Int32.Parse(widthnheight[1]));
                if (newClaim["Left"] + newClaim["Width"] > fabricWidth) fabricWidth = newClaim["Left"] + newClaim["Width"];
                if (newClaim["Top"] + newClaim["Height"] > fabricHeigth) fabricHeigth = newClaim["Top"] + newClaim["Height"];
            }

            for(int i = 0; i < this.fabricHeigth; i++)
            {
                List<int> row = new List<int>();
                for (int j = 0; j < this.fabricWidth; j++)
                {
                    row.Add(0);
                }
                this.fabric.Add(row);
            }
        }

        public void CalculateResult1()
        {
            for(int i = 0; i < this.Claims.Length; i++)
            {
                this.applyClaim();
            }
            result = this.count();
            Console.WriteLine("Fabric Area with more claims is " + result.toString());
        }

        private void applyClaim(Dictionary<string, int> claim)
        {
            for(int i = claim["Top"]-1; i < claim["Top"] + claim["Height"]; i++)
            {
                for(int j = claim["Left"]-1; j < claim["Left"]+claim["Width"]; j++)
                {
                    this.fabric[i][j]++;
                }
            }
        }

        private int count()
        {
            for(int i = 0; i < this.fabric.length; i++)
            {
                for (int j = 0; j < this.fabric[0].length; j++)
                {
                    if (fabric[i][j] > 0)
                    {
                        this.fabricArea++;
                    }
                }
            }
            return this.fabricArea;
        }
    }
}
